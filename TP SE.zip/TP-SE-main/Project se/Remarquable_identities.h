int first_iden(int a,int b);
int second_iden(int a,int b);
int third_iden(int a,int b);
