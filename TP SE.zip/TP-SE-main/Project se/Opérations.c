int multiplication (int number1,int number2){
 return number1*number2;
}
int addition (int number1,int number2){
 return number1+number2;
}
int square(int number){
 return number*number;
}
int substraction(int number1,int number2){
 return number1-number2;
}


